function loadUtilitiess() {
    const loadingIndicator = document.getElementById('loading');
    loadingIndicator.style.display = 'block';

    fetch('utilities.html')
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load content');
            }
            return response.text();
        })
        .then(html => {
            document.getElementById('dynamic-content').innerHTML = html;
        })
        .catch(error => {
            console.error(error);
            document.getElementById('dynamic-content').innerHTML = '<p>Error loading content.</p>';
        })
        .finally(() => {
            loadingIndicator.style.display = 'none';
        });
}
