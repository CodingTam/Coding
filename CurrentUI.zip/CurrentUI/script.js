function loadTriggerData() {
    const testcaseTable = document.getElementById('results-table'); // Testcase table
    const triggerTableBody = document.getElementById('trigger-table-body'); // Trigger table body

    triggerTableBody.innerHTML = ''; // Clear previous rows

    // Iterate through Testcase table rows (skip header row)
    Array.from(testcaseTable.querySelectorAll('tr')).forEach(row => {
        const cells = row.querySelectorAll('td');

        if (cells.length > 0) { // Ensure row has cells
            const testcaseId = cells[1]?.innerText.trim() || '';
            const profile = cells[3]?.innerText.trim() || '';
            const executor = cells[4]?.innerText.trim() || '';

            // Add row to Trigger table if data exists
            if (testcaseId && profile && executor) {
                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                <td><input type="checkbox" class="trigger-checkbox"></td>
                <td>${testcaseId}</td>
                <td>${profile}</td>
                <td>${executor}</td>
                <td class="status-cell">Not Started</td>
            `;
                triggerTableBody.appendChild(newRow);
            }
        }
    });

    if (!triggerTableBody.innerHTML) {
        alert('No test cases available to load!');
    }
}



function triggerSelected() {
    const checkboxes = document.querySelectorAll('.trigger-checkbox:checked');
    checkboxes.forEach(checkbox => {
        const row = checkbox.closest('tr');
        const statusCell = row.querySelector('.status-cell');
        statusCell.innerText = 'In-Progress';

        // Simulate execution and update status
        setTimeout(() => {
            const success = Math.random() > 0.3; // 70% chance of success
            statusCell.innerText = success ? 'Completed' : 'Failed';
        }, 2000); // Simulate a 2-second delay
    });
}


function activateTab1(element, pageId) {
    document.querySelectorAll('.nav-link').forEach(tab => {
        tab.classList.remove('active');
        const img = tab.querySelector('img');
        if (img) {
            img.src = img.getAttribute('data-bw'); // Set to BW icon
        }
    });

    element.classList.add('active');
    const activeImg = element.querySelector('img');
    if (activeImg) {
        activeImg.src = activeImg.getAttribute('data-color'); // Set to color icon
    }

    showPage(pageId);
}






function showPage(pageId) {
    document.querySelectorAll('.container').forEach(page => page.classList.add('hidden'));
    document.getElementById(pageId).classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
    const defaultTab = document.querySelector('.nav-link');
    activateTab(defaultTab, 'create');
});

const sourceSelect = document.getElementById('source');
const targetSelect = document.getElementById('target');
const sourceFields = document.getElementById('source-fields');
const targetFields = document.getElementById('target-fields');
const resultsTable = document.getElementById('results-table');
const resetButton = document.getElementById('reset-button');
const addButton = document.getElementById('add-button');
let testcaseID = 1;

function createFields(selection, container) {
    container.innerHTML = '';
    if (['CSV', 'PSV', 'TXT', 'AVRO', 'PARQUET', 'MARKER'].includes(selection)) {
        container.innerHTML = `
            <div class="form-group">
                <label for="${container.id}-filePath">FilePath</label>
                <input type="text" class="form-control" id="${container.id}-filePath" placeholder="Enter FilePath">
            </div>`;
    } else if (['FIXEDWIDTH', 'FIXEDLENGTH', 'XML', 'JSON', 'DEL'].includes(selection)) {
        container.innerHTML = `
            <div class="form-group">
                <label for="${container.id}-filePath">FilePath</label>
                <input type="text" class="form-control" id="${container.id}-filePath" placeholder="Enter FilePath">
            </div>
            <div class="form-group">
                <label for="${container.id}-copybook">Copybook</label>
                <input type="text" class="form-control" id="${container.id}-copybook" placeholder="Enter Copybook">
            </div>
            <div class="form-group">
                <label for="${container.id}-parameters">Parameters</label>
                <input type="text" class="form-control" id="${container.id}-parameters" placeholder="Enter Parameters">
            </div>`;
    }
}

sourceSelect.addEventListener('change', (e) => createFields(e.target.value, sourceFields));
targetSelect.addEventListener('change', (e) => createFields(e.target.value, targetFields));

resetButton.addEventListener('click', () => {
    sourceSelect.value = '';
    targetSelect.value = '';
    sourceFields.innerHTML = '';
    targetFields.innerHTML = '';
});

document.getElementById("add-button").removeEventListener("click", addTestcase); // Remove any existing listeners
document.getElementById("add-button").addEventListener("click", addTestcase); // Attach the event

function addTestcase_old() {
    const testcaseName = document.getElementById("testcase-name").value || '';
    const profile = document.getElementById("profile").value || '';
    const executor = document.getElementById("executor").value || '';
    const source = document.getElementById("source").value || '';
    const target = document.getElementById("target").value || '';
    const sourceFilepath = document.getElementById("source-fields-filePath")?.value || '';
    const sourceCopybook = document.getElementById("source-fields-copybook")?.value || '';
    const sourceParameters = document.getElementById("source-fields-parameters")?.value || '';
    const targetFilepath = document.getElementById("target-fields-filePath")?.value || '';
    const targetCopybook = document.getElementById("target-fields-copybook")?.value || '';
    const targetParameters = document.getElementById("target-fields-parameters")?.value || '';

    const newRow = `
        <tr>
            <td><input type="checkbox"></td>
            <td>${testcaseID++}</td>
            <td>${testcaseName || ''}</td>
            <td>${profile || ''}</td>
            <td>${executor || ''}</td>
            <td>${source || ''}</td>
            <td>${target || ''}</td>
            <td>${sourceFilepath || ''}</td>
            <td>${sourceCopybook || ''}</td>
            <td>${sourceParameters || ''}</td>
            <td>${targetFilepath || ''}</td>
            <td>${targetCopybook || ''}</td>
            <td>${targetParameters || ''}</td>
            <td><span class="delete-icon" onclick="deleteRow(this)">&#128465;</span></td>
        </tr>`;
    resultsTable.innerHTML += newRow;

    resetButton.click(); // Clear the form
    $('#successPopup').modal('show'); // Show success popup
}

function addTestcase() {
    const testcaseName = document.getElementById("testcase-name").value || '';
    const profile = document.getElementById("profile").value || '';
    const executor = document.getElementById("executor").value || '';
    const source = document.getElementById("source").value || '';
    const target = document.getElementById("target").value || '';
    const sourceFilepath = document.getElementById("source-fields-filePath")?.value || '';
    const sourceCopybook = document.getElementById("source-fields-copybook")?.value || '';
    const sourceParameters = document.getElementById("source-fields-parameters")?.value || '';
    const targetFilepath = document.getElementById("target-fields-filePath")?.value || '';
    const targetCopybook = document.getElementById("target-fields-copybook")?.value || '';
    const targetParameters = document.getElementById("target-fields-parameters")?.value || '';

    // Get validation options
    const allValidation = document.getElementById("allValidation").checked ? "Yes" : "No";
    const schemaValidation = document.getElementById("schemaValidation").checked ? "Yes" : "No";
    const recordCount = document.getElementById("recordCount").checked ? "Yes" : "No";
    const hashMatch = document.getElementById("hashMatch").checked ? "Yes" : "No";
    const dataValidation = document.getElementById("dataValidation").checked ? "Yes" : "No";

    // Add the new row with all columns
    const newRow = `
        <tr>
            <td><input type="checkbox"></td>
            <td>${testcaseID++}</td>
            <td>${testcaseName}</td>
            <td>${profile}</td>
            <td>${executor}</td>
            <td>${source}</td>
            <td>${target}</td>
            <td>${sourceFilepath}</td>
            <td>${sourceCopybook}</td>
            <td>${sourceParameters}</td>
            <td>${targetFilepath}</td>
            <td>${targetCopybook}</td>
            <td>${targetParameters}</td>
            <td>${allValidation}</td>
            <td>${schemaValidation}</td>
            <td>${recordCount}</td>
            <td>${hashMatch}</td>
            <td>${dataValidation}</td>
            <td><span class="delete-icon" onclick="deleteRow(this)">&#128465;</span></td>
        </tr>`;
    resultsTable.innerHTML += newRow;

    // Reset form fields
    resetButton.click();
    $('#successPopup').modal('show'); // Show success popup
}



function deleteRow(deleteIcon) {
    const row = deleteIcon.closest('tr');
    row.remove();
}

function saveSettings() {
    const hostName = document.getElementById('host-name').value;
    const port = document.getElementById('port').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    alert(`Settings Saved:\nHost Name: ${hostName}\nPort: ${port}\nUsername: ${username}`);
}

function updateProfileDropdown33() {
    const profileDropdown = document.getElementById("profile");
    const cardContainer = document.getElementById("cardContainer");
    const cards = cardContainer.querySelectorAll(".card-title input");

    // Clear existing options
    profileDropdown.innerHTML = '<option disabled selected value="">Select Profile</option>';

    // Add options for each card
    cards.forEach(card => {
        const option = document.createElement("option");
        option.value = card.value;
        option.textContent = card.value;
        profileDropdown.appendChild(option);
    
    // Listen for changes in the card input
        card.addEventListener('input', () => {
            updateProfileDropdown();
        });
    });
}

function updateProfileDropdown() {
    const profileDropdown = document.getElementById("profile");
    const cardContainer = document.getElementById("cardContainer");

    if (!profileDropdown || !cardContainer) return; // Ensure elements exist

    const cards = cardContainer.querySelectorAll(".card-title input");

    // Clear existing options
    profileDropdown.innerHTML = '<option disabled selected value="">Select Profile</option>';

    cards.forEach(card => {
        if (!card) return; // Skip if card input doesn't exist
        const option = document.createElement("option");
        option.value = card.value;
        option.textContent = card.value;
        profileDropdown.appendChild(option);

        // Attach listener for input changes
        card.addEventListener("input", () => {
            updateProfileDropdown();
        });
    });
}


// Hook into the Add New Card functionality to update the dropdown
document.getElementById("addCardBtn").addEventListener("click", () => {
    setTimeout(updateProfileDropdown, 100); // Delay to ensure the card is added
});




// Initial population on page load
document.addEventListener("DOMContentLoaded", updateProfileDropdown);


function toggleAllCheckboxes(selectAllCheckbox) {
    const checkboxes = document.querySelectorAll('.validation-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
}

document.querySelectorAll('.validation-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', () => {
        const allCheckboxes = Array.from(document.querySelectorAll('.validation-checkbox'));
        document.getElementById('selectAll').checked = allCheckboxes.every(cb => cb.checked);
    });
});

function toggleAllCheckboxes(selectAllCheckbox) {
    // Select all checkboxes with the "validation-checkbox" class
    const checkboxes = document.querySelectorAll('.validation-checkbox');
    // Set each checkbox to match the state of the "All" checkbox
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
}

// Add event listeners to individual checkboxes to manage the "All" checkbox state
document.querySelectorAll('.validation-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', () => {
        const allCheckboxes = Array.from(document.querySelectorAll('.validation-checkbox'));
        // Check if all individual checkboxes are selected
        const allChecked = allCheckboxes.every(cb => cb.checked);
        // Update the "All" checkbox based on the state of the individual checkboxes
        document.getElementById('selectAll').checked = allChecked;
    });
});

resetButton.addEventListener('click', () => {
    document.getElementById("testcase-name").value = '';
    document.getElementById("profile").value = '';
    document.getElementById("executor").value = '';
    document.getElementById("source").value = '';
    document.getElementById("target").value = '';
    document.getElementById("source-fields").innerHTML = '';
    document.getElementById("target-fields").innerHTML = '';
    document.querySelectorAll('.form-check-input').forEach(checkbox => {
        checkbox.checked = false;
    });
});

const table = document.querySelector('.table-style');
if (table) {
    table.style.margin = '20px auto';
    table.style.maxWidth = '90%';
}

function activateTab(element, pageId) {
    // Remove 'active' from all tabs
    document.querySelectorAll('.nav-link').forEach(tab => tab.classList.remove('active'));

    // Add 'active' to the clicked tab
    element.classList.add('active');

    // Hide all containers
    document.querySelectorAll('.container, .container-fluid').forEach(page => {
        page.classList.add('hidden');
    });

    // Show the selected container
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.classList.remove('hidden');
    }

    // Additional logic specific to 'create' page
    if (pageId === 'create') {
        const testcaseTableBody = document.getElementById('results-table');
        if (testcaseTableBody) {
            testcaseTableBody.innerHTML = ''; // Clear table content
        }
    }
    document.querySelectorAll('.nav-link').forEach(tab => {
        tab.classList.remove('active');
        const img = tab.querySelector('img');
        if (img) {
            img.src = img.getAttribute('data-bw'); // Set to BW icon
        }
    });

    element.classList.add('active');
    const activeImg = element.querySelector('img');
    if (activeImg) {
        activeImg.src = activeImg.getAttribute('data-color'); // Set to color icon
    }

    showPage(pageId);
}

function logout() {
    // Clear any session storage or user data
    alert("You have been logged out successfully!");
    // Redirect to login page
    window.location.href = "login.html";
}