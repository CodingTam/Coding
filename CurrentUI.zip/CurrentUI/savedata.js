
// Save data in localStorage
// Clear all data for Testcase
function clearTestcaseData() {
    localStorage.removeItem("testcaseData");
    document.getElementById("results-table").innerHTML = "";
}

// Clear all data for Profiles
function clearProfileData() {
    localStorage.removeItem("profileData");
    localStorage.removeItem("cardCounter");
    document.getElementById("cardContainer").innerHTML = "";
    cardCounter = 0;
    updateAddButton();
}

// Auto-save data whenever the content changes
function attachAutoSave() {
    const saveTriggers = ["results-table", "cardContainer"];
    saveTriggers.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener("DOMSubtreeModified", saveData);
        }
    });
}

// Attach delete row function
function deleteRow(deleteIcon) {
    const row = deleteIcon.closest("tr");
    row.remove();
    saveData();
}


