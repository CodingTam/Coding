const loginToggle = document.getElementById("login-toggle");
const registerToggle = document.getElementById("register-toggle");
const loginForm = document.getElementById("login-form");
const registerForm = document.getElementById("register-form");

loginToggle.addEventListener("click", () => {
    loginForm.classList.add("active");
    registerForm.classList.remove("active");
    loginToggle.classList.add("active");
    registerToggle.classList.remove("active");
});

registerToggle.addEventListener("click", () => {
    registerForm.classList.add("active");
    loginForm.classList.remove("active");
    registerToggle.classList.add("active");
    loginToggle.classList.remove("active");
});

// Hardcoded credentials
const hardcodedUsername = "admin";
const hardcodedPassword = "admin";

loginForm.addEventListener("submit", (event) => {
    event.preventDefault(); // Prevent the default form submission

    // Get input values
    const enteredUsername = document.getElementById("login-email").value;
    const enteredPassword = document.getElementById("login-password").value;

    // Check if the entered credentials match the hardcoded ones
    if (enteredUsername === hardcodedUsername && enteredPassword === hardcodedPassword) {
        alert("Login successful! Welcome, " + enteredUsername + "!");
        // Redirect to another page or take any desired action
        window.location.href = "dashboard.html";
    } else {
        alert("Invalid username or password. Please try again.");
    }
});

loginForm.addEventListener("submit", (event) => {
    event.preventDefault(); // Prevent the form from submitting normally

    // Add your login validation logic here (if any)

    // Redirect to the 'create' page
    window.location.href = "index.html#create";
});
