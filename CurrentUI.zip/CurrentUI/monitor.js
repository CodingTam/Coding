document.addEventListener('DOMContentLoaded', () => {
    const collapsibleRows = document.querySelectorAll('.collapsible');

    collapsibleRows.forEach(row => {
        row.addEventListener('click', () => {
            const targetClass = row.getAttribute('data-target');
            const targetRows = document.querySelectorAll(`.${targetClass}`);

            row.classList.toggle('active'); // Toggle arrow icon
            targetRows.forEach(targetRow => {
                if (targetRow.classList.contains('hidden')) {
                    targetRow.classList.remove('hidden');
                } else {
                    targetRow.classList.add('hidden');
                }
            });
        });
    });
});
